import os
import time
import random
import re
import logging
import threading
from datetime import datetime, timedelta

from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS

import requests
from bs4 import BeautifulSoup
from rank_bm25 import BM25Okapi
import nltk
from xml.etree import ElementTree as ET

from selenium import webdriver
from selenium.webdriver.chrome.options import Options as ChromeOptions
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, WebDriverException

from apscheduler.schedulers.background import BackgroundScheduler

# --- Setup ---
app = Flask(__name__,
            static_folder='.',
            static_url_path='',
            template_folder='templates')
CORS(app)

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(name)s - %(message)s')
logger = logging.getLogger(__name__)
werkzeug_logger = logging.getLogger('werkzeug')
werkzeug_logger.setLevel(logging.INFO)

# NLTK setup
try:
    nltk.data.find('tokenizers/punkt')
except LookupError:
    logger.info("NLTK 'punkt' tokenizer not found. Downloading...")
    nltk.download('punkt', quiet=True)
    logger.info("'punkt' downloaded.")

# --- Proxy Configuration & Management ---
PROXY_FILE = "proxies.txt"
MY_PROXY_LIST = []
CURRENT_PROXY_INDEX = 0
PROXY_REFRESH_INTERVAL_HOURS = 1
CHROMEDRIVER_PATH = None  # Set to None if chromedriver is in PATH

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36",
]

# --- Helper Functions ---
def tokenize(text):
    if not text:
        return []
    return nltk.word_tokenize(text.lower())

def load_proxies_from_file():
    global MY_PROXY_LIST, CURRENT_PROXY_INDEX
    try:
        if os.path.exists(PROXY_FILE):
            with open(PROXY_FILE, 'r') as f:
                proxies = [line.strip() for line in f if line.strip()]
            if proxies:
                MY_PROXY_LIST = proxies
                CURRENT_PROXY_INDEX = 0
                logger.info(f"Successfully loaded {len(MY_PROXY_LIST)} proxies from {PROXY_FILE}.")
            else:
                MY_PROXY_LIST = []
                logger.warning(f"{PROXY_FILE} was empty or contained no valid proxies.")
        else:
            MY_PROXY_LIST = []
            logger.warning(f"{PROXY_FILE} not found. No proxies loaded.")
    except Exception as e:
        logger.error(f"Error loading proxies from {PROXY_FILE}: {e}", exc_info=True)
        MY_PROXY_LIST = []

def validate_proxy_file():
    """Validate that the proxy file exists and contains valid proxies."""
    if not os.path.exists(PROXY_FILE):
        logger.warning(f"Proxy file {PROXY_FILE} does not exist")
        return False
    
    try:
        with open(PROXY_FILE, 'r') as f:
            lines = [line.strip() for line in f if line.strip()]
        
        if not lines:
            logger.warning(f"Proxy file {PROXY_FILE} is empty")
            return False
        
        valid_proxies = 0
        for line in lines:
            if ':' in line and (line.startswith('http://') or line.startswith('socks') or ':' in line.split('://')[-1]):
                valid_proxies += 1
        
        if valid_proxies == 0:
            logger.warning(f"No valid proxies found in {PROXY_FILE}")
            return False
        
        logger.info(f"Validated {valid_proxies} proxies in {PROXY_FILE}")
        return True
        
    except Exception as e:
        logger.error(f"Error validating proxy file: {e}")
        return False

def get_random_proxy_for_requests():
    """Returns a proxy dict for the `requests` library, or None."""
    global CURRENT_PROXY_INDEX, MY_PROXY_LIST
    if not MY_PROXY_LIST:
        return None
    
    proxy_url_full = MY_PROXY_LIST[CURRENT_PROXY_INDEX % len(MY_PROXY_LIST)]
    CURRENT_PROXY_INDEX += 1
    
    return {"http": proxy_url_full, "https": proxy_url_full}

def fetch_and_save_proxies():
    """Fetch proxies from ProxyScrape using Selenium to click the download button."""
    logger.info("Attempting to fetch fresh proxies from ProxyScrape...")
    
    chrome_options = ChromeOptions()
    chrome_options.add_argument("--headless")
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")
    chrome_options.add_argument("--disable-gpu")
    chrome_options.add_argument("--disable-blink-features=AutomationControlled")
    chrome_options.add_argument("--disable-extensions")
    chrome_options.add_argument("--disable-plugins")
    chrome_options.add_argument("--disable-images")
    chrome_options.add_argument("--disable-javascript")  # We'll enable it later if needed
    chrome_options.add_argument("--window-size=1920,1080")
    chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
    chrome_options.add_experimental_option('useAutomationExtension', False)
    chrome_options.add_argument(f"user-agent={random.choice(USER_AGENTS)}")
    
    # Set download directory
    download_dir = os.path.abspath(os.path.dirname(__file__))
    prefs = {
        "download.default_directory": download_dir,
        "download.prompt_for_download": False,
        "download.directory_upgrade": True,
        "safebrowsing.enabled": True,
        "profile.default_content_settings.popups": 0,
        "profile.default_content_setting_values.notifications": 2
    }
    chrome_options.add_experimental_option("prefs", prefs)

    driver = None
    try:
        if CHROMEDRIVER_PATH:
            service = webdriver.chrome.service.Service(executable_path=CHROMEDRIVER_PATH)
            driver = webdriver.Chrome(service=service, options=chrome_options)
        else:
            driver = webdriver.Chrome(options=chrome_options)
        
        driver.execute_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
        
        proxyscrape_url = "https://proxyscrape.com/free-proxy-list"
        logger.info(f"Navigating to: {proxyscrape_url}")
        
        driver.get(proxyscrape_url)
        
        # Re-enable JavaScript if the page needs it
        driver.execute_script("return navigator.userAgent")
        
        # Wait for page to load completely
        WebDriverWait(driver, 30).until(
            lambda d: d.execute_script("return document.readyState") == "complete"
        )
        
        # Wait for specific elements to be present
        try:
            WebDriverWait(driver, 20).until(
                EC.any_of(
                    EC.presence_of_element_located((By.TAG_NAME, "table")),
                    EC.presence_of_element_located((By.CLASS_NAME, "proxy")),
                    EC.presence_of_element_located((By.XPATH, "//button[contains(., 'Download')]"))
                )
            )
        except TimeoutException:
            logger.warning("Page elements not found within timeout, proceeding anyway...")
        
        # Give the page additional time to fully render
        time.sleep(5)
        
        # Log page title for debugging
        logger.info(f"Page title: {driver.title}")
        
        # Try multiple strategies to find the download button
        download_button = None
        
        # Strategy 1: Look for button containing the SVG path and "Download" text
        try:
            download_button = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((By.XPATH, "//button[contains(., 'Download') and .//svg]"))
            )
            logger.info("Found download button using Strategy 1")
        except TimeoutException:
            pass
        
        # Strategy 2: Look for button with specific SVG path
        if not download_button:
            try:
                download_button = WebDriverWait(driver, 5).until(
                    EC.element_to_be_clickable((By.XPATH, "//button[.//svg/path[contains(@d, 'M17 16v1h-17v-1h17z')]]"))
                )
                logger.info("Found download button using Strategy 2")
            except TimeoutException:
                pass
        
        # Strategy 3: Look for button with small tag containing "Download"
        if not download_button:
            try:
                download_button = WebDriverWait(driver, 5).until(
                    EC.element_to_be_clickable((By.XPATH, "//button[.//small[contains(text(), 'Download')]]"))
                )
                logger.info("Found download button using Strategy 3")
            except TimeoutException:
                pass
        
        # Strategy 4: Look for any clickable element with "Download" text
        if not download_button:
            try:
                download_button = WebDriverWait(driver, 5).until(
                    EC.element_to_be_clickable((By.XPATH, "//*[contains(text(), 'Download') and (self::button or self::a)]"))
                )
                logger.info("Found download button using Strategy 4")
            except TimeoutException:
                pass
        
        if not download_button:
            logger.error("Could not find download button on ProxyScrape page")
            return False
        
        # Clean up any existing downloaded file
        # FIXED: Use different temporary filenames that won't conflict with our target file
        temp_files = ["free-proxy-list.txt", "http_proxies.txt", "proxy_list.txt", "proxies_temp.txt"]
        for temp_file in temp_files:
            temp_path = os.path.join(download_dir, temp_file)
            if os.path.exists(temp_path):
                os.remove(temp_path)
                logger.info(f"Removed existing file: {temp_file}")
        
        # Handle potential overlays and click the download button
        logger.info("Attempting to click the download button...")
        
        # Try to dismiss any overlays first
        try:
            # Look for common overlay dismissal elements
            overlay_dismissers = [
                "//button[contains(text(), 'Accept')]",
                "//button[contains(text(), 'OK')]",
                "//button[contains(text(), 'Close')]",
                "//button[contains(@class, 'close')]",
                "//*[@class='modal-close']",
                "//*[contains(@class, 'cookie-accept')]",
                "//*[contains(@class, 'banner-close')]"
            ]
            
            for dismisser_xpath in overlay_dismissers:
                try:
                    overlay_element = driver.find_element(By.XPATH, dismisser_xpath)
                    if overlay_element.is_displayed():
                        logger.info(f"Found overlay element, dismissing: {dismisser_xpath}")
                        overlay_element.click()
                        time.sleep(1)
                        break
                except:
                    continue
        except Exception as e:
            logger.debug(f"No overlays found or error dismissing: {e}")
        
        # Multiple click strategies
        click_successful = False
        
        # Strategy 1: Regular click
        try:
            logger.info("Trying regular click...")
            driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", download_button)
            time.sleep(2)
            download_button.click()
            click_successful = True
            logger.info("Regular click successful")
        except Exception as e:
            logger.warning(f"Regular click failed: {e}")
        
        # Strategy 2: JavaScript click
        if not click_successful:
            try:
                logger.info("Trying JavaScript click...")
                driver.execute_script("arguments[0].click();", download_button)
                click_successful = True
                logger.info("JavaScript click successful")
            except Exception as e:
                logger.warning(f"JavaScript click failed: {e}")
        
        # Strategy 3: ActionChains click
        if not click_successful:
            try:
                from selenium.webdriver.common.action_chains import ActionChains
                logger.info("Trying ActionChains click...")
                actions = ActionChains(driver)
                actions.move_to_element(download_button).click().perform()
                click_successful = True
                logger.info("ActionChains click successful")
            except Exception as e:
                logger.warning(f"ActionChains click failed: {e}")
        
        # Strategy 4: Force click with retry
        if not click_successful:
            try:
                logger.info("Trying force click with overlay removal...")
                # Try to remove any potential overlay elements
                driver.execute_script("""
                    var overlays = document.querySelectorAll('.modal, .popup, .overlay, .banner, [style*="position: fixed"], [style*="position: absolute"]');
                    overlays.forEach(function(overlay) {
                        if (overlay.style.zIndex > 1000 || overlay.style.position === 'fixed' || overlay.style.position === 'absolute') {
                            overlay.style.display = 'none';
                        }
                    });
                """)
                
                time.sleep(1)
                driver.execute_script("arguments[0].click();", download_button)
                click_successful = True
                logger.info("Force click successful")
            except Exception as e:
                logger.warning(f"Force click failed: {e}")
        
        if not click_successful:
            logger.error("All click strategies failed, trying direct API as fallback...")
            
            # Fallback to direct API download
            try:
                api_urls = [
                    "https://api.proxyscrape.com/v2/?request=displayproxies&protocol=http&timeout=10000&country=all&ssl=all&anonymity=all&format=textplain",
                    "https://api.proxyscrape.com/v2/?request=displayproxies&protocol=socks4&timeout=10000&country=all&format=textplain",
                    "https://api.proxyscrape.com/v2/?request=displayproxies&protocol=socks5&timeout=10000&country=all&format=textplain"
                ]
                
                all_proxies = []
                for api_url in api_urls:
                    try:
                        logger.info(f"Trying API: {api_url}")
                        response = requests.get(api_url, timeout=30, headers={"User-Agent": random.choice(USER_AGENTS)})
                        response.raise_for_status()
                        
                        if response.text.strip():
                            proxies = response.text.strip().split('\n')
                            protocol = "http" if "protocol=http" in api_url else ("socks4" if "protocol=socks4" in api_url else "socks5")
                            
                            for proxy in proxies:
                                proxy = proxy.strip()
                                if proxy and ':' in proxy:
                                    if "://" not in proxy:
                                        all_proxies.append(f"{protocol}://{proxy}")
                                    else:
                                        all_proxies.append(proxy)
                    except Exception as api_e:
                        logger.warning(f"API {api_url} failed: {api_e}")
                        continue
                
                if all_proxies:
                    with open(PROXY_FILE, 'w') as f:
                        for proxy in all_proxies:
                            f.write(f"{proxy}\n")
                    
                    logger.info(f"Successfully saved {len(all_proxies)} proxies from API fallback to {PROXY_FILE}")
                    load_proxies_from_file()
                    return True
                else:
                    logger.error("API fallback also failed - no proxies obtained")
                    return False
                    
            except Exception as fallback_e:
                logger.error(f"API fallback error: {fallback_e}")
                return False
        
        # Wait for download to complete
        download_wait_time = 30
        downloaded_file = None
        
        # FIXED: Look for the actual downloaded file, not our target file
        while download_wait_time > 0:
            for temp_file in temp_files:
                temp_path = os.path.join(download_dir, temp_file)
                if os.path.exists(temp_path) and os.path.getsize(temp_path) > 0:
                    downloaded_file = temp_path
                    break
            
            if downloaded_file:
                break
            
            time.sleep(1)
            download_wait_time -= 1
        
        if not downloaded_file:
            logger.error("Download failed or timed out. No proxy file found.")
            return False
        
        logger.info(f"Proxies downloaded to: {downloaded_file}")
        
        # Read and process the downloaded file
        with open(downloaded_file, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        
        # Process the content to extract proxies
        processed_proxies = []
        for line in content.splitlines():
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            
            # Handle different formats
            if "://" in line:
                # Already has protocol
                processed_proxies.append(line)
            elif ":" in line and line.count(':') == 1:
                # Assume HTTP if no protocol specified
                processed_proxies.append(f"http://{line}")
        
        if not processed_proxies:
            logger.warning("No valid proxies found in downloaded file")
            return False
        
        # Save to our proxy file
        with open(PROXY_FILE, 'w') as f:
            for proxy in processed_proxies:
                f.write(f"{proxy}\n")
        
        logger.info(f"Successfully saved {len(processed_proxies)} proxies to {PROXY_FILE}")
        
        # FIXED: Only clean up downloaded file if it's different from our target file
        if downloaded_file != PROXY_FILE and os.path.exists(downloaded_file):
            os.remove(downloaded_file)
            logger.info(f"Cleaned up temporary file: {downloaded_file}")
        
        # Reload proxies into memory
        load_proxies_from_file()
        
        return True
        
    except Exception as e:
        logger.error(f"Error during proxy fetching: {e}", exc_info=True)
        return False
    finally:
        if driver:
            try:
                driver.quit()
            except Exception as e:
                logger.error(f"Error closing driver: {e}")
                
def scheduled_proxy_fetch_job():
    """Background job to fetch proxies periodically."""
    logger.info("Running scheduled job: fetch_and_save_proxies")
    try:
        success = fetch_and_save_proxies()
        if success:
            logger.info("Scheduled proxy fetch completed successfully")
        else:
            logger.warning("Scheduled proxy fetch failed")
    except Exception as e:
        logger.error(f"Error in scheduled proxy fetch job: {e}", exc_info=True)

# --- Frontend Serving Routes ---
@app.route('/')
def serve_index():
    if os.path.exists(os.path.join(app.root_path, 'index.html')):
        return send_from_directory(app.root_path, 'index.html')
    return "index.html not found", 404

@app.route('/<path:filename>')
def serve_static_or_template(filename):
    if filename in ['script.js', 'styles.css', 'index.html']:
        if os.path.exists(os.path.join(app.root_path, filename)):
            return send_from_directory(app.root_path, filename)
    return "File not found", 404

# --- API Routes ---
@app.route('/api/search-scholar', methods=['POST'])
def search_google_scholar_route():
    data = request.json
    query = data.get('query')
    max_results = int(data.get('max_results', 10))
    year_low = data.get('year_low')
    year_high = data.get('year_high')

    if not query:
        return jsonify({"error": "Query is required"}), 400
    
    logger.info(f"Google Scholar search: query='{query}', max_results={max_results}, yl={year_low}, yh={year_high}")

    current_request_proxies = get_random_proxy_for_requests()
    headers = {"User-Agent": random.choice(USER_AGENTS)}
    
    num_to_fetch = min(max_results, 20)
    scholar_url = f"https://scholar.google.com/scholar?q={requests.utils.quote(query)}&hl=en&num={num_to_fetch}"
    if year_low:
        scholar_url += f"&as_ylo={year_low}"
    if year_high:
        scholar_url += f"&as_yhi={year_high}"

    logger.info(f"Requesting Scholar URL: {scholar_url}")
    if current_request_proxies:
        logger.info(f"Using proxy: {current_request_proxies.get('http')}")
    else:
        logger.info("No proxy available for this Scholar request.")

    results = []
    
    try:
        response = requests.get(scholar_url, headers=headers, proxies=current_request_proxies, timeout=25)
        response.raise_for_status()
        
        if "blocked" in response.text.lower() or "captcha" in response.text.lower():
            logger.warning("Google Scholar request may be blocked or requires CAPTCHA")
            return jsonify({"error": "Request blocked by Google Scholar"}), 429
        
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # Parse Google Scholar results
        for result_div in soup.find_all('div', class_='gs_r gs_or gs_scl'):
            try:
                # Extract title
                title_element = result_div.find('h3', class_='gs_rt')
                if not title_element:
                    continue
                
                title_link = title_element.find('a')
                title = title_link.get_text() if title_link else title_element.get_text()
                url = title_link.get('href') if title_link else ""
                
                # Extract authors and publication info
                authors_element = result_div.find('div', class_='gs_a')
                authors = authors_element.get_text() if authors_element else ""
                
                # Extract abstract/snippet
                snippet_element = result_div.find('div', class_='gs_rs')
                abstract = snippet_element.get_text() if snippet_element else ""
                
                # Extract citations
                citations_element = result_div.find('div', class_='gs_fl')
                citations = 0
                if citations_element:
                    cite_link = citations_element.find('a', string=re.compile(r'Cited by \d+'))
                    if cite_link:
                        cite_match = re.search(r'Cited by (\d+)', cite_link.get_text())
                        if cite_match:
                            citations = int(cite_match.group(1))
                
                # Extract year
                year = ""
                if authors:
                    year_match = re.search(r', (\d{4})', authors)
                    if year_match:
                        year = year_match.group(1)
                
                result = {
                    'title': title.strip(),
                    'authors': authors.strip(),
                    'abstract': abstract.strip(),
                    'url': url,
                    'year': year,
                    'citations': citations,
                    'source': 'Google Scholar',
                    'relevanceScore': 1.0
                }
                
                results.append(result)
                
            except Exception as e:
                logger.error(f"Error parsing individual Scholar result: {e}")
                continue
        
        logger.info(f"Google Scholar parse processed {len(results)} items.")
        
    except requests.exceptions.Timeout:
        logger.error("Timeout during Google Scholar request.", exc_info=True)
        return jsonify({"error": "Timeout requesting Google Scholar."}), 504
    except requests.exceptions.RequestException as e:
        logger.error(f"Error during Google Scholar request: {e}", exc_info=True)
        return jsonify({"error": f"Error requesting Google Scholar: {str(e)}"}), 503
    except Exception as e:
        logger.error(f"Error parsing Google Scholar results: {e}", exc_info=True)
        return jsonify({"error": f"Error parsing Google Scholar results: {str(e)}"}), 500
            
    return jsonify(results)

@app.route('/api/search-pubmed', methods=['POST'])
def search_pubmed_route():
    data = request.json
    raw_query = data.get('query') 
    max_results = int(data.get('max_results', 10))
    filters = data.get('filters', {})

    if not raw_query: 
        return jsonify({"error": "Query is required"}), 400

    # Clean query for PubMed
    pubmed_search_term = raw_query
    pubmed_search_term = re.sub(r'(?:cat:|ti:|au:|abs:)\s*', ' ', pubmed_search_term, flags=re.IGNORECASE)
    pubmed_search_term = re.sub(r'[\[\]\(\)\{\}]', ' ', pubmed_search_term)
    pubmed_search_term = ' '.join(pubmed_search_term.split()).strip()

    logger.info(f"PubMed search: Original='{raw_query}', Cleaned='{pubmed_search_term}', max_results={max_results}")

    if not pubmed_search_term:
        logger.warning(f"PubMed query became empty after cleaning. Original: '{raw_query}'.")
        return jsonify([])

    papers = []
    
    try:
        # Step 1: Search for PMIDs
        search_url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi"
        search_params = {
            'db': 'pubmed',
            'term': pubmed_search_term,
            'retmax': min(max_results, 100),
            'retmode': 'xml'
        }
        
        search_response = requests.get(search_url, params=search_params, timeout=30)
        search_response.raise_for_status()
        
        search_root = ET.fromstring(search_response.content)
        pmids = [id_elem.text for id_elem in search_root.findall('.//Id')]
        
        if not pmids:
            logger.info("No PMIDs found for PubMed query")
            return jsonify([])
        
        logger.info(f"Found {len(pmids)} PMIDs")
        
        # Step 2: Fetch details for PMIDs
        fetch_url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi"
        fetch_params = {
            'db': 'pubmed',
            'id': ','.join(pmids),
            'retmode': 'xml'
        }
        
        fetch_response = requests.get(fetch_url, params=fetch_params, timeout=60)
        fetch_response.raise_for_status()
        
        fetch_root = ET.fromstring(fetch_response.content)
        
        for article in fetch_root.findall('.//PubmedArticle'):
            try:
                # Extract title
                title_elem = article.find('.//ArticleTitle')
                title = title_elem.text if title_elem is not None else "No title"
                
                # Extract authors
                authors = []
                for author in article.findall('.//Author'):
                    last_name = author.find('LastName')
                    first_name = author.find('ForeName')
                    if last_name is not None and first_name is not None:
                        authors.append(f"{first_name.text} {last_name.text}")
                    elif last_name is not None:
                        authors.append(last_name.text)
                
                authors_str = ", ".join(authors) if authors else "Unknown authors"
                
                # Extract abstract
                abstract_elem = article.find('.//Abstract/AbstractText')
                abstract = abstract_elem.text if abstract_elem is not None else ""
                
                # Extract publication year
                year_elem = article.find('.//PubDate/Year')
                year = year_elem.text if year_elem is not None else ""
                
                # Extract journal
                journal_elem = article.find('.//Journal/Title')
                journal = journal_elem.text if journal_elem is not None else ""
                
                # Extract PMID
                pmid_elem = article.find('.//PMID')
                pmid = pmid_elem.text if pmid_elem is not None else ""
                
                paper = {
                    'title': title,
                    'authors': authors_str,
                    'abstract': abstract,
                    'year': year,
                    'journal': journal,
                    'pmid': pmid,
                    'url': f"https://pubmed.ncbi.nlm.nih.gov/{pmid}/" if pmid else "",
                    'source': 'PubMed',
                    'relevanceScore': 1.0,
                    'citations': 0
                }
                
                papers.append(paper)
                
            except Exception as e:
                logger.error(f"Error parsing PubMed article: {e}")
                continue
        
        logger.info(f"Successfully parsed {len(papers)} PubMed articles")
        
    except requests.exceptions.RequestException as e:
        logger.error(f"Error during PubMed request: {e}", exc_info=True)
        return jsonify({"error": f"Error requesting PubMed: {str(e)}"}), 503
    except ET.ParseError as e:
        logger.error(f"Error parsing PubMed XML: {e}", exc_info=True)
        return jsonify({"error": "Error parsing PubMed response"}), 500
    except Exception as e:
        logger.error(f"Unexpected error during PubMed search: {e}", exc_info=True)
        return jsonify({"error": f"Unexpected error: {str(e)}"}), 500
    
    return jsonify(papers)

@app.route('/api/rank-bm25', methods=['POST'])
def rank_bm25_route():
    data = request.json
    papers_data = data.get('papers')
    verbose_query = data.get('verbose_query')

    if not papers_data or not verbose_query:
        return jsonify({"error": "Papers data and verbose query are required"}), 400

    try:
        corpus = [str(paper.get('abstract', '') or '') for paper in papers_data]
        tokenized_corpus = [tokenize(doc) for doc in corpus]
        tokenized_query = tokenize(verbose_query)

        if not any(tokenized_corpus) and not tokenized_query:
            for paper in papers_data:
                paper['bm25_score'] = paper['relevanceScore'] = 0.0
            return jsonify(papers_data)
            
        if not any(tokenized_corpus):
            for paper in papers_data:
                paper['bm25_score'] = paper['relevanceScore'] = 0.0
            return jsonify(papers_data)
            
        if not tokenized_query:
            for paper in papers_data:
                paper['bm25_score'] = paper['relevanceScore'] = 0.0
            return jsonify(papers_data)

        bm25 = BM25Okapi(tokenized_corpus)
        doc_scores = bm25.get_scores(tokenized_query)
        
        for paper, score in zip(papers_data, doc_scores):
            paper['bm25_score'] = float(score) if score is not None else 0.0
            paper['relevanceScore'] = float(score) if score is not None else 0.0
            
    except Exception as e:
        logger.error(f"Error during BM25 ranking: {e}", exc_info=True)
        for paper in papers_data:
            paper['bm25_score'] = paper.get('bm25_score', 0.0)
            paper['relevanceScore'] = paper.get('relevanceScore', 0.0)
        return jsonify({"error": f"Error during BM25 ranking: {str(e)}", "ranked_papers_fallback": papers_data}), 500
    
    return jsonify(papers_data)

@app.route('/api/proxy-status', methods=['GET'])
def proxy_status():
    """API endpoint to check proxy status."""
    return jsonify({
        'proxy_count': len(MY_PROXY_LIST),
        'current_index': CURRENT_PROXY_INDEX,
        'file_exists': os.path.exists(PROXY_FILE),
        'last_updated': datetime.fromtimestamp(os.path.getmtime(PROXY_FILE)).isoformat() if os.path.exists(PROXY_FILE) else None
    })

# --- Background Scheduler ---
scheduler = BackgroundScheduler(daemon=True)

if __name__ == '__main__':
    # Initial proxy setup with validation
    if not validate_proxy_file():
        logger.info(f"{PROXY_FILE} not found or invalid, attempting initial fetch.")
        fetch_and_save_proxies()
    else:
        # Check file age
        try:
            file_mod_time = datetime.fromtimestamp(os.path.getmtime(PROXY_FILE))
            if datetime.now() - file_mod_time > timedelta(hours=PROXY_REFRESH_INTERVAL_HOURS * 0.9):
                logger.info(f"{PROXY_FILE} is older than refresh interval, fetching new proxies.")
                fetch_and_save_proxies()
            else:
                load_proxies_from_file()
        except Exception as e:
            logger.error(f"Error checking proxy file age: {e}")
            fetch_and_save_proxies()
    
    if not MY_PROXY_LIST:
        logger.warning("No proxies available after initial fetch attempts. Scholar searches may fail or get blocked.")

    # Schedule the proxy fetching job
    scheduler.add_job(
        scheduled_proxy_fetch_job, 
        'interval', 
        hours=PROXY_REFRESH_INTERVAL_HOURS, 
        id='proxy_fetch_job', 
        replace_existing=True
    )
    scheduler.start()
    logger.info(f"Proxy refresh job scheduled to run every {PROXY_REFRESH_INTERVAL_HOURS} hour(s).")
    
    # Start the Flask app
    try:
        app.run(debug=True, host='0.0.0.0', port=5001, use_reloader=False)
    except KeyboardInterrupt:
        logger.info("Shutting down...")
    finally:
        if scheduler.running:
            scheduler.shutdown()
            logger.info("Scheduler shut down.")